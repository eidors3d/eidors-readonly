Five pigs before (e.g. 1-control.raw) and after induction of unilateral lung injury 
(e.g. 1-injury.raw). Oleic acid was administered through the distal opening of a
pulmonary artery catheter placed in a branch of the left pulmonary artery.

Ventilator settings:
VOlume-controlled ventilation
PEEP: 5 cm H2O
FIO2: 0.5
Fresp: 12 /min
The ventilator settings were not changed!
 
EIT data was acquired with the Sheffield APT device Mk 1.
Measurement duration 240 s, frame rate 1 Hz.


The study was published (Frerichs et al. Electrical impedance tomography in monitoring 
experimental lung injury. Intensive Care Med 1998, 24, 829-836). If the data is used then
a reference to this publication should be made. 

