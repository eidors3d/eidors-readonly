﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EITsurfer.PhantomRobot
{
    public partial class PhantomRobotControlWindow : Form
    {
        public PhantomRobotControlWindow()
        {
            InitializeComponent();
        }

        private void positioningSystem1_Load(object sender, EventArgs e)
        {

        }
    }
}
