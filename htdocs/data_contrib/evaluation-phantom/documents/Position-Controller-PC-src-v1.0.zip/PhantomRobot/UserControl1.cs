﻿/******************************************
*  EIT - Phantom - Positioning - System : *
*                                         *
*  EIT-P-PS - Program                     *
*                                         *
*  25.08.09 - Sascha Reidt                *
******************************************/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NKH.MindSqualls;
using System.IO;
using System.Threading;
using System.Collections;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;



namespace EITsurfer.PhantomRobot
{ 
   
    
    public partial class PositioningSystem : UserControl
    {

        public bool IsBusy //isbusyparameter
        {
            set;
            get;
        }

        public int[] Coord;

        public delegate void positionReachedHandler(object sender, EventArgs e); //delegates und events kreieren

        public event positionReachedHandler positionReached;

        public delegate void positionLeavedHandler(object sender, EventArgs e);

        public event positionLeavedHandler positionLeaved;


        public PositioningSystem()
        {
            InitializeComponent();
            textBox12.Text = "<NAME>";
            IsBusy = false;
            Coord=new int[6];
        }

        private  double CalculateAngle(int x1d, int x2d, int y1d, int y2d)
        {
            double dy = (y2d - y1d);
            double dx = (x2d - x1d);
            double phi2d = Math.Atan(dy/dx);                        //Berechnung Steigungswinkel
            phi2d = (phi2d * 180) / Math.PI;                     //Rad in Bogenmass
            phi2d = Math.Round(phi2d, 0);                         //Runden auf ein Grad
            return (phi2d);
        }

        private void  SendKoords(string x1, string y1, string z1, string x2, string y2, string z2, string phi2, byte Port)
        {
            NxtBluetoothConnection conn = new NxtBluetoothConnection(Port);//NXT-Verbindung
            try
            {
                conn.Connect();
                System.Threading.Thread.Sleep(200);
                conn.MessageWrite(0, x1);                                   //Versenden der Koords                                        
                System.Threading.Thread.Sleep(200);
                conn.MessageWrite(0, y1);
                System.Threading.Thread.Sleep(200);
                conn.MessageWrite(0, z1);
                System.Threading.Thread.Sleep(200);
                conn.MessageWrite(0, x2);
                System.Threading.Thread.Sleep(200);
                conn.MessageWrite(0, y2);
                System.Threading.Thread.Sleep(200);
                conn.MessageWrite(0, z2); ;
                System.Threading.Thread.Sleep(200);
                conn.MessageWrite(0, phi2);
                conn.Disconnect();
            return;
            }                                //Verbinden  
            catch (Exception IOE)
            {
                System.Threading.Thread.Sleep(1000);
                try
                {
                    conn.Connect();
                    System.Threading.Thread.Sleep(200);
                    conn.MessageWrite(0, x1);                                   //Versenden der Koords                                        
                    System.Threading.Thread.Sleep(200);
                    conn.MessageWrite(0, y1);
                    System.Threading.Thread.Sleep(200);
                    conn.MessageWrite(0, z1);
                    System.Threading.Thread.Sleep(200);
                    conn.MessageWrite(0, x2);
                    System.Threading.Thread.Sleep(200);
                    conn.MessageWrite(0, y2);
                    System.Threading.Thread.Sleep(200);
                    conn.MessageWrite(0, z2); ;
                    System.Threading.Thread.Sleep(200);
                    conn.MessageWrite(0, phi2);
                    conn.Disconnect();
                    return;
                }

                catch (Exception CFB)
                {
                    MessageBox.Show(Convert.ToString(IOE), "Cannot find brick!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    IsBusy = false;
                }


            }



        }

        private static string StopProgram(byte port)
        {
                NxtBluetoothConnection conn = new NxtBluetoothConnection(port);//NXT-Verbindung, prgme stoppen
                conn.Connect();
                System.Threading.Thread.Sleep(200);
                conn.StopProgram();
                System.Threading.Thread.Sleep(200);
                conn.Disconnect();
            return "warum muss ich hier einen string returnieren?";
        }

        private static string StartProgram(byte port)
        {
            NxtBluetoothConnection conn = new NxtBluetoothConnection(port);//NXT-Verbindung, prgme stoppen
            conn.Connect();
            System.Threading.Thread.Sleep(200);
            conn.StartProgram("Prgm EIT-P-PS_N.rxe");
            System.Threading.Thread.Sleep(200);
            conn.Disconnect();
            return "warum muss ich hier einen string returnieren?";
        }

        private bool ReceiveResponse(byte port)
        {
            NxtBluetoothConnection conn = new NxtBluetoothConnection(port);//NXT-Verbindung
            conn.Connect();
            System.Threading.Thread.Sleep(200);
            int k = 0;
            while (k<1)
            {
                string msg = conn.MessageRead(0, 0, false); // wenn ändern des Inhalts mB 0 in slr
                if (msg == "slr")
                {
                    k = k + 1;
                    msg = conn.MessageRead(0, 0, true);
                }
            }
            conn.Disconnect();
            return true;
        }




        private bool CheckKoords(int x1d, int x2d, int y1d, int y2d, int z1d, int z2d, int cb1i, int cb2i)//OBJEKTGROESSE BERÜCKSICHTIGEN
        {

            double dO1 = Math.Sqrt(2 * (cb1i/2) ^ 2);
            double dO2 = Math.Sqrt(2 * (cb2i/2) ^ 2);

            if ((x2d * x2d + y2d * y2d) > ((140 - dO2) * (140 - dO2)) || (z2d * z2d) > ((150 - dO2) * (150 - dO2)))               //Obj2 in Zylinder?
            {
                MessageBox.Show("Position of objekt 2 is not reachable!");
                return false;
            }
            else if ((x1d * x1d + y1d * y1d) > ((140 - dO1) * (140 - dO1)) || (z1d * z1d) > ((150 - dO1) * (150 - dO1)))          //Obj1 in Zylinder?
            {
                MessageBox.Show("Position of objekt 1 is not reachable!");
                return false;
            }
            else if ((Math.Abs(x1d - x2d)) <= (cb1i) && (Math.Abs(y1d - y2d)) <= (cb1i) && (Math.Abs(z1d - z2d)) <= (cb1i) && checkBox3.Checked == true) //!!!cb2i auch beachten
            {
                MessageBox.Show("Distance of the positions is to short!");     //Obj 1 und 2 auf selbe pos?
                return false;
            }
            else
                return true;
        }


        private static string CheckObj(string cb)   //durchmesser der objekte holen
        {
            switch (cb)
            {
                case "1ml-bar":
                    return (Convert.ToString(10));
                case "10ml-bar":
                case "10ml-cube":
                    return (Convert.ToString(21.54));
                case "50ml-cube":
                    return (Convert.ToString(36.84));
                case "100ml-cube":
                    return (Convert.ToString(46.42));
                case "10ml-ball":
                    return (Convert.ToString(26.73));
                case "100ml-ball":
                    return (Convert.ToString(57.6));
                case "-":
                    return (Convert.ToString(0));
                default:
                    MessageBox.Show("Please choose an object!");
                    return (Convert.ToString(100));
            }
        }





        private void button1_Click(object sender, EventArgs e)
        {

            backgroundWorker1.RunWorkerAsync();
           
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("C:/Users/User/Desktop/Bluetooth Devices - Shortcut");
            }
            catch (Exception)
            {
                MessageBox.Show("To add the controllers, please open 'Bluetooth Devices' in control panel manually.", "Cannot find 'Add Bluetooth Device Wizard'!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }




        public void WriteFile(String sFilename, String sLines)
        {
            StreamWriter myFile = new StreamWriter(sFilename);
            myFile.Write(sLines);
            myFile.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {


            try
            {
                double enr = Convert.ToDouble(textBox7.Text);   //Einlesen der Koords aus Input Position in double
                double rad = Convert.ToDouble(textBox8.Text);
                double vert1 = Convert.ToDouble(textBox9.Text);
                string cb1 = comboBox1.Text;
                double vert2 = 0;
                double dist = 0;
                string cb2 = "";
                string radtan = "";
                if (checkBox3.Checked == true)
                {
                     vert2 = Convert.ToDouble(textBox11.Text);
                     dist = Convert.ToDouble(textBox10.Text);
                     cb2 = comboBox2.Text;
                     radtan = comboBox3.Text;
                }
                double phi;
                double x1d;
                double y1d;
                double z1d;
                double x2d = 0;
                double y2d = 0;
                double z2d = 0;


                double cb1d = Convert.ToDouble(CheckObj(cb1));      //durchmesser holen
                

                double vz;          //vorzeichen eingabe

                vz = Math.Abs(dist) / dist;                             //Vorzeichen dist

                phi = (Math.PI) / 2 - (enr * 0.19635);                                     //Bogenmass
                x1d = rad * Math.Cos(phi);                        //Koords mit Polarform k*e^phi i rechnen
                y1d = rad * Math.Sin(phi);
                z1d = vert1;

                if (radtan == "rad" && checkBox3.Checked == true)
                {
                    double cb2d = Convert.ToDouble(CheckObj(cb2));
                    x2d = (rad - (cb2d * dist+vz*cb2d)) * Math.Cos(phi);       //Koords mit Polarform , verändertes k, berechnen
                    y2d = (rad - (cb2d * dist+vz*cb2d)) * Math.Sin(phi);
                    z2d = vert2;
                }
                else if (radtan == "tan" && checkBox3.Checked == true)
                {
                    double cb2d = Convert.ToDouble(CheckObj(cb2));
                    double alpha;       //hilfsvariablen alpha(winkeldifferenz pos1 und pos2)
                    double alphan;      //alpha nenner
                    double alphaz;      //alpha zähler

                    alphaz = Math.Abs(dist)*cb2d + cb2d;                   //zähler alpha mit Trigonometrie berechnen
                    alphan = 2 * rad;                //nenner alpha mit Trigo berechnen
                    alpha = alphaz / alphan;                //alpha ist halber zwischenwinkel pos1 / ursprung / pos2

                    phi =  (Math.PI) / 2 - (enr * 0.19635 + 2 * vz * (Math.Asin(alpha)));     //neues phi ist 2*zwischenwinkel alpha plus drehwinkel pos1

                    x2d = rad * Math.Cos(phi);             //Berechnung koords mit verändertem phi
                    y2d = rad * Math.Sin(phi);
                    z2d = vert2;
                }
                else if (radtan != "tan" && radtan != "rad" && checkBox3.Checked == true)
                    MessageBox.Show("Please choose tan or rad","Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else if (checkBox3.Checked == false)
                {
                    x2d = 0;
                    y2d = 0;
                    z2d = 0;
                }


                if (radtan == "rad" || radtan == "tan" || checkBox3.Checked == false)
                {
                    x1d = Math.Round(x1d, 0);       //resultate runden
                    y1d = Math.Round(y1d, 0);
                    z1d = Math.Round(z1d, 0);
                    x2d = Math.Round(x2d, 0);
                    y2d = Math.Round(y2d, 0);
                    z2d = Math.Round(z2d, 0);

                    textBox1.Text = Convert.ToString(x1d);     //koordinaten in textbox1-6 ausgeben
                    textBox2.Text = Convert.ToString(y1d);
                    textBox3.Text = Convert.ToString(z1d);
                    textBox4.Text = Convert.ToString(x2d);
                    textBox5.Text = Convert.ToString(y2d);
                    textBox6.Text = Convert.ToString(z2d);
                }
            }
            catch (Exception e2)
            {
                MessageBox.Show("Please fill in whole numbers!","Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }



        private void button4_Click(object sender, EventArgs e)
        {
            try
            {

                int x1d = Convert.ToInt16(textBox1.Text);   //Einlesen der Koords aus Textbox in char
                int y1d = Convert.ToInt16(textBox2.Text);
                int z1d = Convert.ToInt16(textBox3.Text);
                int x2d = Convert.ToInt16(textBox4.Text);
                int z2d = Convert.ToInt16(textBox6.Text);
                int y2d = Convert.ToInt16(textBox5.Text);


                string cb1 = comboBox1.Text;
                string cb2 = comboBox2.Text;
                
                double cb1d = Convert.ToDouble(CheckObj(cb1));      //durchmesser holen
                int cb1i = Convert.ToInt16(Math.Round(cb1d));

                double cb2d = Convert.ToDouble(CheckObj(cb2));
                int cb2i = Convert.ToInt16(Math.Round(cb2d));


                bool input = CheckKoords(x1d, x2d, y1d, y2d, z1d, z2d, cb1i, cb2i);

                if (input == true && cb1d != 100)
                {
                    //comboBox1.Enabled = false;
                    //comboBox2.Enabled = false;
                    string x1 = Convert.ToString(x1d);                      //Alle Double to String um zu versenden
                    string x2 = Convert.ToString(x2d);
                    string y1 = Convert.ToString(y1d);
                    string y2 = Convert.ToString(y2d);
                    string z1 = Convert.ToString(z1d);
                    string z2 = Convert.ToString(z2d);

                    
                    
                    checkBox3.Enabled = false;

                    System.Windows.Forms.ListViewItem coords = new System.Windows.Forms.ListViewItem(x1);
                    System.Windows.Forms.ListViewItem.ListViewSubItem y1si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, y1);
                    System.Windows.Forms.ListViewItem.ListViewSubItem z1si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, z1);
                    System.Windows.Forms.ListViewItem.ListViewSubItem x2si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, x2);
                    System.Windows.Forms.ListViewItem.ListViewSubItem y2si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, y2);
                    System.Windows.Forms.ListViewItem.ListViewSubItem z2si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, z2);
                    coords.SubItems.Add(y1si);
                    coords.SubItems.Add(z1si);
                    coords.SubItems.Add(x2si);
                    coords.SubItems.Add(y2si);
                    coords.SubItems.Add(z2si);
                    listView1.Items.Add(coords);

                    int nop = Convert.ToInt16(label28.Text);
                    nop = nop + 1;
                    comboBox1.Enabled = false;
                    comboBox2.Enabled = false;
                    label28.Text = Convert.ToString(nop);

                    try
                    {
                        System.Windows.Forms.ListViewItem pos = new System.Windows.Forms.ListViewItem(textBox7.Text);
                        System.Windows.Forms.ListViewItem.ListViewSubItem rad = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, textBox8.Text);
                        System.Windows.Forms.ListViewItem.ListViewSubItem vert1 = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, textBox9.Text);
                        System.Windows.Forms.ListViewItem.ListViewSubItem radtan = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, comboBox3.Text);
                        System.Windows.Forms.ListViewItem.ListViewSubItem dist = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, textBox10.Text);
                        System.Windows.Forms.ListViewItem.ListViewSubItem vert2 = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, textBox11.Text);
                        pos.SubItems.Add(rad);
                        pos.SubItems.Add(vert1);
                        pos.SubItems.Add(radtan);
                        pos.SubItems.Add(dist);
                        pos.SubItems.Add(vert2);
                        listView2.Items.Add(pos);
                    }
                    catch (FormatException FE)
                    {
                       // MessageBox.Show( Convert.ToString(FE),"Please fill in whole numbers!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }



                }
            }


            catch (Exception e3)
            {
                MessageBox.Show("Please fill in whole numbers!", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            int nop = Convert.ToInt16(label28.Text);
            if (nop == 0)
            {
                textBox12.Enabled = true;
                textBox13.Enabled = true;
                comboBox1.Enabled = true;
                comboBox2.Enabled = true;
                checkBox3.Enabled = true;
            }


            else
            {
                try
                {

                    int deleteitem = listView1.SelectedIndices[0];

                    listView1.Items.RemoveAt(deleteitem);
                    listView2.Items.RemoveAt(deleteitem);
                    nop = nop - 1;
                    label28.Text = Convert.ToString(nop);
                }



                catch (Exception deleteitemlv1)
                {
                    try
                    {
                        int deleteitem = listView2.SelectedIndices[0];

                        listView1.Items.RemoveAt(deleteitem);
                        listView2.Items.RemoveAt(deleteitem);
                        nop = nop - 1;
                        label28.Text = Convert.ToString(nop);

                    }
                    catch (Exception deleteitemlv2)
                    {
                        MessageBox.Show("Please select an item!", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
                textBox15.Enabled = true;
            else
            {
                textBox15.Enabled = false;
                textBox15.Text = "0";
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string help = treeView1.SelectedNode.Text;

           if (help == "Connection")
           {
                   textBox17.Visible = true;
                   textBox18.Visible = false;
                   textBox19.Visible = false;
                   textBox20.Visible = false;
                   textBox21.Visible = false;
                   textBox22.Visible = false;
                   textBox23.Visible = false;
                   textBox24.Visible = false;
           }
           else if (help == "Bluetooth-Problems")
           {
               textBox17.Visible = false;
               textBox18.Visible = true;
               textBox19.Visible = false;
               textBox20.Visible = false;
               textBox21.Visible = false;
               textBox22.Visible = false;
               textBox23.Visible = false;
               textBox24.Visible = false;
           }
           else if (help == "Positions")
           {
               textBox17.Visible = false;
               textBox18.Visible = false;
               textBox19.Visible = true;
               textBox20.Visible = false;
               textBox21.Visible = false;
               textBox22.Visible = false;
               textBox23.Visible = false;
               textBox24.Visible = false;
           }
           else if (help == "Coordinates")
           {
               textBox17.Visible = false;
               textBox18.Visible = false;
               textBox19.Visible = false;
               textBox20.Visible = true;
               textBox21.Visible = false;
               textBox22.Visible = false;
               textBox23.Visible = false;
               textBox24.Visible = false;
           }
           else if (help == "Protocol")
           {
               textBox17.Visible = false;
               textBox18.Visible = false;
               textBox19.Visible = false;
               textBox20.Visible = false;
               textBox21.Visible = true;
               textBox22.Visible = false;
               textBox23.Visible = false;
               textBox24.Visible = false;
           }
           else if (help == "Start")
           {
               textBox17.Visible = false;
               textBox18.Visible = false;
               textBox19.Visible = false;
               textBox20.Visible = false;
               textBox21.Visible = false;
               textBox22.Visible = true;
               textBox23.Visible = false;
               textBox24.Visible = false;
           }
           else if (help == "Options")
           {
               textBox17.Visible = false;
               textBox18.Visible = false;
               textBox19.Visible = false;
               textBox20.Visible = false;
               textBox21.Visible = false;
               textBox22.Visible = false;
               textBox23.Visible = true;
               textBox24.Visible = false;
           }
           else if (help == "Initialization")
           {
               textBox17.Visible = false;
               textBox18.Visible = false;
               textBox19.Visible = false;
               textBox20.Visible = false;
               textBox21.Visible = false;
               textBox22.Visible = false;
               textBox23.Visible = false;
               textBox24.Visible = true;
           }

            
 

        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                string port1 = textBox13.Text;
                string port2 = textBox14.Text;
                IsBusy = true;
                NxtBluetoothConnection NXT1 = new NxtBluetoothConnection(Convert.ToByte(port1));//NXT-Verbindung
                NXT1.Connect();                                           //Verbinden  
                System.Threading.Thread.Sleep(200);
                NXT1.StartProgram("initialization_.rxe");
                System.Threading.Thread.Sleep(200);
                NXT1.Disconnect();
                NxtBluetoothConnection NXT2 = new NxtBluetoothConnection(Convert.ToByte(port2));//NXT-Verbindung
                NXT2.Connect();                                           //Verbinden  
                System.Threading.Thread.Sleep(200);
                NXT2.StartProgram("initialization_.rxe");
                System.Threading.Thread.Sleep(200);
                NXT2.Disconnect();
            }

            catch (ArgumentException AE)
            {
                MessageBox.Show(Convert.ToString(AE), "Please choose a valid name!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                IsBusy = false;
            }
            catch (FormatException FE)
            {
                MessageBox.Show(Convert.ToString(FE), "Please fill in whole numbers!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                IsBusy = false;
            }
            catch (Exception IOE)
            {
                MessageBox.Show(Convert.ToString(IOE), "Cannot find brick!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                IsBusy = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                comboBox2.Enabled = true;
                comboBox3.Enabled = true;
                comboBox5.Enabled = true;
                textBox10.Enabled = true;
                textBox11.Enabled = true;
                textBox4.Enabled = true;
                textBox5.Enabled = true;
                textBox6.Enabled = true;
            }
            else
            {
                comboBox2.Enabled = false;
                comboBox2.Text = "-";
                comboBox3.Enabled = false;
                comboBox3.Text = "-";
                comboBox5.Enabled = false;
                comboBox5.Text = "-";
                textBox10.Enabled = false;
                textBox10.Text = "-";
                textBox11.Enabled = false;
                textBox11.Text = "-";
                textBox4.Enabled = false;
                textBox4.Text = "0";
                textBox5.Enabled = false;
                textBox5.Text = "0";
                textBox6.Enabled = false;
                textBox6.Text = "0";
                MessageBox.Show("Please make sure that you remove carriage 2 before you start the positioning of one object!", "Positioning of one Object", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                string loadloc = textBox25.Text;
                Excel.Application oXL;
                Excel._Workbook oWB;
                Excel._Worksheet oSheet;
                Excel.Range CurRange;

                System.Globalization.CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;

                System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

                oXL = new Excel.Application();


                oWB = (Excel._Workbook)(oXL.Workbooks.Open(@"" + loadloc, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value));
                oSheet = (Excel._Worksheet)oWB.ActiveSheet;

                CurRange = (Excel.Range)oSheet.Cells[2, 1];
                string nop = (string)CurRange.Text;
                int nopi = Convert.ToInt16(nop);
                int nope = nopi;

                CurRange = (Excel.Range)oSheet.Cells[4, 2];
                string cb1 = (string)CurRange.Text;

                CurRange = (Excel.Range)oSheet.Cells[5, 2];
                string cb2 = (string)CurRange.Text;

                CurRange = (Excel.Range)oSheet.Cells[4, 3];
                string con1 = (string)CurRange.Text;

                CurRange = (Excel.Range)oSheet.Cells[5, 3];
                string con2 = (string)CurRange.Text;


                if (label28.Text == "0" || (cb1 == comboBox1.Text && cb2 == comboBox2.Text))
                {

                    for (int i = 1; i <= nope; i++)
                    {
                        comboBox1.Text = cb1;
                        comboBox2.Text = cb2;
                        comboBox4.Text = con1;
                        comboBox5.Text = con2;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 1];
                        string x1 = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 2];
                        string y1 = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 3];
                        string z1 = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 4];
                        string x2 = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 5];
                        string y2 = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 6];
                        string z2 = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 8];
                        string ENr = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 9];
                        string Rad = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 10];
                        string Vert1 = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 11];
                        string Radtan = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 12];
                        string Dist = (string)CurRange.Text;
                        CurRange = (Excel.Range)oSheet.Cells[i + 10, 13];
                        string Vert2 = (string)CurRange.Text;

                        double cb1d = Convert.ToDouble(CheckObj(cb1));      //durchmesser holen
                        double cb2d = Convert.ToDouble(CheckObj(cb2));
                        double x1d = 0;
                        double y1d = 0;
                        double z1d = 0;
                        double x2d = 0;
                        double y2d = 0;
                        double z2d = 0;


                        if (x1 == "" && ENr != "")
                        {

                            double ENrd = Convert.ToDouble(ENr);
                            double Radd = Convert.ToDouble(Rad);
                            double Vert1d = Convert.ToDouble(Vert1);
                            double Distd = Convert.ToDouble(Dist);
                            double Vert2d = Convert.ToDouble(Vert2);


                            double vz;          //vorzeichen eingabe

                            vz = Math.Abs(Distd) / Distd;                             //Vorzeichen dist

                            double phi = (Math.PI) / 2 - (ENrd * 0.19635);                                     //Bogenmass
                            x1d = Radd * Math.Cos(phi);                        //Koords mit Polarform k*e^phi i rechnen
                            y1d = Radd * Math.Sin(phi);
                            z1d = Vert1d;

                            if (Radtan == "rad")
                            {

                                x2d = (Radd - (cb2d * Distd + vz * cb2d)) * Math.Cos(phi);       //Koords mit Polarform , verändertes k, berechnen
                                y2d = (Radd - (cb2d * Distd + vz * cb2d)) * Math.Sin(phi);
                                z2d = Vert2d;
                            }
                            else if (Radtan == "tan")
                            {
                                double alpha;       //hilfsvariablen alpha(winkeldifferenz pos1 und pos2)
                                double alphan;      //alpha nenner
                                double alphaz;      //alpha zähler

                                alphaz = Math.Abs(Distd) * cb2d + cb2d;                   //zähler alpha mit Trigonometrie berechnen
                                alphan = 2 * Radd;                //nenner alpha mit Trigo berechnen
                                alpha = alphaz / alphan;                //alpha ist halber zwischenwinkel pos1 / ursprung / pos2

                                phi = (Math.PI) / 2 - (ENrd * 0.19635 + 2 * vz * (Math.Asin(alpha)));     //neues phi ist 2*zwischenwinkel alpha plus drehwinkel pos1

                                x2d = Radd * Math.Cos(phi);             //Berechnung koords mit verändertem phi
                                y2d = Radd * Math.Sin(phi);
                                z2d = Vert2d;
                            }

                            x1 = Convert.ToString(Math.Round(x1d, 0));       //resultate runden
                            y1 = Convert.ToString(Math.Round(y1d, 0));
                            z1 = Convert.ToString(Math.Round(z1d, 0));
                            x2 = Convert.ToString(Math.Round(x2d, 0));
                            y2 = Convert.ToString(Math.Round(y2d, 0));
                            z2 = Convert.ToString(Math.Round(z2d, 0));

                        }
                        x1d = Convert.ToDouble(x1);
                        y1d = Convert.ToDouble(y1);
                        z1d = Convert.ToDouble(z1);
                        x2d = Convert.ToDouble(x2);
                        y2d = Convert.ToDouble(y2);
                        z2d = Convert.ToDouble(z2);



                        int cb1i = Convert.ToInt16(Math.Round(cb1d, 0));
                        int cb2i = Convert.ToInt16(Math.Round(cb2d, 0));

                        string input;

                        double dO1 = Math.Sqrt(2 * (cb1i / 2) ^ 2);
                        double dO2 = Math.Sqrt(2 * (cb2i / 2) ^ 2);

                        if ((x2d * x2d + y2d * y2d) > ((140 - dO2) * (140 - dO2)) || (z2d * z2d) > ((150 - dO2) * (150 - dO2)) || (x1d * x1d + y1d * y1d) > ((140 - dO1) * (140 - dO1)) || (z1d * z1d) > ((150 - dO1) * (150 - dO1)))               //Obj2 in Zylinder?
                        {
                            input = "false_reachability";
                        }
                        else if ((Math.Abs(x1d - x2d)) <= (cb1i) && (Math.Abs(y1d - y2d)) <= (cb1i) && (Math.Abs(z1d - z2d)) <= (cb1i) && checkBox3.Checked == true) //!!!cb2i auch beachten
                        {
                            MessageBox.Show("Distance of the positions number " + i + " is to short!", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Warning);    //Obj 1 und 2 auf selbe pos?
                            input = "false_distance";

                        }
                        else
                            input = "true";



                        if (input == "true")
                        {



                            System.Windows.Forms.ListViewItem coords = new System.Windows.Forms.ListViewItem(x1);
                            System.Windows.Forms.ListViewItem.ListViewSubItem y1si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, y1);
                            System.Windows.Forms.ListViewItem.ListViewSubItem z1si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, z1);
                            System.Windows.Forms.ListViewItem.ListViewSubItem x2si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, x2);
                            System.Windows.Forms.ListViewItem.ListViewSubItem y2si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, y2);
                            System.Windows.Forms.ListViewItem.ListViewSubItem z2si = new System.Windows.Forms.ListViewItem.ListViewSubItem(coords, z2);
                            coords.SubItems.Add(y1si);
                            coords.SubItems.Add(z1si);
                            coords.SubItems.Add(x2si);
                            coords.SubItems.Add(y2si);
                            coords.SubItems.Add(z2si);
                            listView1.Items.Add(coords);

                            System.Windows.Forms.ListViewItem pos = new System.Windows.Forms.ListViewItem(ENr);
                            System.Windows.Forms.ListViewItem.ListViewSubItem rad = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, Rad);
                            System.Windows.Forms.ListViewItem.ListViewSubItem vert1 = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, Vert1);
                            System.Windows.Forms.ListViewItem.ListViewSubItem radtan = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, Radtan);
                            System.Windows.Forms.ListViewItem.ListViewSubItem dist = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, Dist);
                            System.Windows.Forms.ListViewItem.ListViewSubItem vert2 = new System.Windows.Forms.ListViewItem.ListViewSubItem(pos, Vert2);
                            pos.SubItems.Add(rad);
                            pos.SubItems.Add(vert1);
                            pos.SubItems.Add(radtan);
                            pos.SubItems.Add(dist);
                            pos.SubItems.Add(vert2);
                            listView2.Items.Add(pos);

                            label28.Text = Convert.ToString(1 + Convert.ToInt16(label28.Text));
                            comboBox1.Enabled = false;
                            comboBox2.Enabled = false;
                        }
                        else if (input != "true")
                        {
                            if (input == "false_reachability")
                            {
                                string invpos = Convert.ToString(i);
                                MessageBox.Show("Position " + i + " is not reachable!", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            else if (input == "false_distance")
                            {
                                MessageBox.Show("Distance of positions " + i + " is to short!", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            nopi = nopi - 1;
                        }
                    }




                    oXL.Quit();
                }
                else
                {
                    MessageBox.Show("The choosen objects are not the same!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

            }
            catch (ArgumentException AE)
            {
                MessageBox.Show(Convert.ToString(AE), "Please choose a valid name!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (FormatException FE)
            {
                MessageBox.Show(Convert.ToString(FE), "Please fill in whole numbers!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception IOE)
            {
                MessageBox.Show(Convert.ToString(IOE), "Please choose a valid path!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string cb1 = comboBox1.Text;
            string cb2 = comboBox2.Text;
            string imp1 = comboBox4.Text;
            string imp2 = comboBox5.Text;
            string name = textBox12.Text;
            double phi2d;
            int nop = Convert.ToInt16(label28.Text);

            System.Globalization.CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;

            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

            
            Excel.Application oXL;
            Excel._Workbook oWB;
            Excel._Worksheet oSheet;
            Excel.Range oRng;



            DateTime today = DateTime.Now;
            string date = Convert.ToString(today);
            string justdate = date.Substring(0, 10);
            string nops = Convert.ToString(nop);

            oXL = new Excel.Application();              //Start Excel and get Application object.
            oXL.Visible = true;

            oWB = (Excel._Workbook)(oXL.Workbooks.Add(Missing.Value));      //Get a new workbook.
            oSheet = (Excel._Worksheet)oWB.ActiveSheet;

            oSheet.get_Range("A1", "B1").Font.Bold = true;           //Format A1:B1 as bold
            oSheet.get_Range("A7", "O7").Font.Bold = true;
            //oSheet.get_Range("A1", "D1").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

            oSheet.Cells[1, 1] = "Protocol";
            oSheet.Cells[1, 2] = name;
            oSheet.Cells[1, 4] = justdate;
            oSheet.Cells[2, 2] = "positions";
            oSheet.Cells[2, 1] = nop;
            oSheet.Cells[4, 1] = "Object 1:";
            oSheet.Cells[5, 1] = "Object 2:";
            oSheet.Cells[9, 1] = "Object 1:";
            oSheet.Cells[9, 4] = "Object 2:";
            oSheet.Cells[9, 8] = "Object 1:";
            oSheet.Cells[9, 11] = "Object 2:";
            oSheet.Cells[4, 2] = cb1;
            oSheet.Cells[5, 2] = cb2;
            oSheet.Cells[4, 3] = imp1;
            oSheet.Cells[5, 3] = imp2;
            oSheet.Cells[7, 1] = "Coordinates:";
            oSheet.Cells[10, 1] = "x1";
            oSheet.Cells[10, 2] = "y1";
            oSheet.Cells[10, 3] = "z1";
            oSheet.Cells[10, 4] = "x2";
            oSheet.Cells[10, 5] = "y2";
            oSheet.Cells[10, 6] = "z2";
            oSheet.Cells[7, 8] = "Positions:";
            oSheet.Cells[10, 8] = "ENr";
            oSheet.Cells[10, 9] = "Rad";
            oSheet.Cells[10, 10] = "Vert1";
            oSheet.Cells[10, 11] = "rad/tan";
            oSheet.Cells[10, 12] = "Dist.";
            oSheet.Cells[10, 13] = "Vert2";

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                button8.Enabled = false;
                textBox25.Enabled = false;
                button7.Enabled = false;
                label36.Enabled = false;
                checkBox4.Checked = false;
                textBox16.Enabled = true;
                label32.Enabled = true;
                groupBox3.Enabled = true;
                groupBox5.Enabled = false;
                MessageBox.Show("Certain options will not be enabled!", "Store protocol as textfile", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                button8.Enabled = true;
                textBox25.Enabled = true;
                button7.Enabled = true;
                label36.Enabled = true;
                checkBox5.Checked = false;
                textBox16.Enabled = false;
                label32.Enabled = false;
                groupBox3.Enabled = false;
                groupBox5.Enabled = true;
            }

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {


                string cb1 = comboBox1.Text;
                string cb2 = comboBox2.Text;
                string imp1 = comboBox4.Text;
                string imp2 = comboBox5.Text;
                string name = textBox12.Text;
                string port1 = textBox13.Text;
                string port2 = textBox14.Text;
                string path = textBox16.Text;
                double phi2d;
                int nop = Convert.ToInt16(label28.Text);
                StopProgram(Convert.ToByte(port1));
                System.Threading.Thread.Sleep(500);
                StopProgram(Convert.ToByte(port2));
                System.Threading.Thread.Sleep(200);
                StartProgram(Convert.ToByte(port1));             //Prgme starten
                System.Threading.Thread.Sleep(500);
                StartProgram(Convert.ToByte(port2));


                System.Globalization.CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;

                System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

                Excel.Application oXL;
                Excel._Workbook oWB;
                Excel._Worksheet oSheet;
                Excel.Range oRng;


                oXL = new Excel.Application();              //Start Excel and get Application object.
                oXL.Visible = true;

                oWB = (Excel._Workbook)(oXL.Workbooks.Add(Missing.Value));      //Get a new workbook.
                oSheet = (Excel._Worksheet)oWB.ActiveSheet;



                DateTime today = DateTime.Now;
                string date = Convert.ToString(today);
                string justdate = date.Substring(0, 10);
                int i;
                string storeloc = path + " " + name;
                string nops = Convert.ToString(nop);


                if (checkBox5.Checked == false)
                {


                    oSheet.get_Range("A1", "B1").Font.Bold = true;           //Format A1:B1 as bold
                    oSheet.get_Range("A7", "O7").Font.Bold = true;


                    oSheet.Cells[1, 1] = "Protocol";
                    oSheet.Cells[1, 2] = name;
                    oSheet.Cells[1, 4] = justdate;
                    oSheet.Cells[2, 2] = "positions";
                    oSheet.Cells[2, 1] = nop;
                    oSheet.Cells[4, 1] = "Object 1:";
                    oSheet.Cells[5, 1] = "Object 2:";
                    oSheet.Cells[9, 1] = "Object 1:";
                    oSheet.Cells[9, 4] = "Object 2:";
                    oSheet.Cells[9, 8] = "Object 1:";
                    oSheet.Cells[9, 11] = "Object 2:";
                    oSheet.Cells[4, 2] = cb1;
                    oSheet.Cells[5, 2] = cb2;
                    oSheet.Cells[4, 3] = imp1;
                    oSheet.Cells[5, 3] = imp2;
                    oSheet.Cells[7, 1] = "Coordinates:";
                    oSheet.Cells[10, 1] = "x1";
                    oSheet.Cells[10, 2] = "y1";
                    oSheet.Cells[10, 3] = "z1";
                    oSheet.Cells[10, 4] = "x2";
                    oSheet.Cells[10, 5] = "y2";
                    oSheet.Cells[10, 6] = "z2";
                    oSheet.Cells[7, 8] = "Positions:";
                    oSheet.Cells[10, 8] = "ENr";
                    oSheet.Cells[10, 9] = "Rad";
                    oSheet.Cells[10, 10] = "Vert1";
                    oSheet.Cells[10, 11] = "rad/tan";
                    oSheet.Cells[10, 12] = "Dist.";
                    oSheet.Cells[10, 13] = "Vert2";
                    oSheet.Cells[9, 15] = "Time:";
                    oSheet.Cells[1, 6] = "Status:";
                    oSheet.get_Range("G1", "G1").Interior.ColorIndex = 3;
                }
                else if (checkBox5.Checked == true)
                {
                    StreamWriter myWriter = File.CreateText(@"" + storeloc);
                    myWriter.WriteLine("Protocol:{0}     {1}", name, date);
                    myWriter.WriteLine(" ");
                    myWriter.WriteLine("{0} positions", nop);
                    myWriter.WriteLine(" ");
                    myWriter.WriteLine(" ");
                    myWriter.WriteLine("Object 1/Object 2");
                    myWriter.WriteLine("{0}/{1}", cb1, cb2);
                    myWriter.WriteLine("{0}/{1}", imp1, imp2);
                    myWriter.WriteLine(" ");
                    myWriter.WriteLine("Time:        x / y / z");
                    myWriter.WriteLine("------------------------- ");
                }




                for (i = 0; i < nop; i++)
                {

                    string x1 = listView1.Items[i].SubItems[0].Text;                   //Alle Double to String um zu versenden 
                    string y1 = listView1.Items[i].SubItems[1].Text;
                    string z1 = listView1.Items[i].SubItems[2].Text;
                    string x2 = listView1.Items[i].SubItems[3].Text;
                    string y2 = listView1.Items[i].SubItems[4].Text;
                    string z2 = listView1.Items[i].SubItems[5].Text;

                    string ENr = listView2.Items[i].SubItems[0].Text;                   //Alle Double to String um zu versenden 
                    string Rad = listView2.Items[i].SubItems[1].Text;
                    string Vert1 = listView2.Items[i].SubItems[2].Text;
                    string rt = listView2.Items[i].SubItems[3].Text;
                    string Dist = listView2.Items[i].SubItems[4].Text;
                    string Vert2 = listView2.Items[i].SubItems[5].Text;


                    int x1d = Convert.ToInt16(x1);                              //string zu int für winkel
                    int x2d = Convert.ToInt16(x2);
                    int y1d = Convert.ToInt16(y1);
                    int y2d = Convert.ToInt16(y2);
                    int z1d = Convert.ToInt16(z1);
                    int z2d = Convert.ToInt16(z2);


                    if (x2d - x1d == 0)                                  //wenn gerade senkrecht-->keine Funktion
                    { phi2d = 90; }
                    else
                    { phi2d = CalculateAngle(x1d, x2d, y1d, y2d); }         //ansonsten Winkel berechnen 


                    double cb1d = Convert.ToDouble(CheckObj(cb1));
                    double cb2d = Convert.ToDouble(CheckObj(cb1));

                    if (cb1 != "10ml-bar" && cb1 != "1ml-bar" && cb2 != "10ml-bar" && cb2 != "1ml-bar")
                    {
                        z1d = Convert.ToInt16(Math.Round(z1d + (cb1d / 2)));
                        z2d = Convert.ToInt16(Math.Round(z2d + (cb2d / 2)));
                        z1 = Convert.ToString(z1d);
                        z2 = Convert.ToString(z2d);
                    }


                    string phi2 = Convert.ToString(phi2d);              //zu strin gum zu versenden
                    if (checkBox3.Checked == false)
                    {
                        phi2 = "2491";
                        x2 = "0";
                        y2 = "0";
                        z2 = "0";
                    }

                    IsBusy = true;                                      //is busy

                    
                    Coord[0] = x1d;
                    Coord[1] = y1d;
                    Coord[2] = Convert.ToInt16(Math.Round(z1d + (cb1d / 2)));
                    Coord[3] = x2d;
                    Coord[4] = y2d;
                    Coord[5] = Convert.ToInt16(Math.Round(z2d + (cb2d / 2)));

                    if (positionLeaved != null)                         //event pos. verlassen triggern
                        positionLeaved(null, null);

                    //x1 = Convert.ToString((-1) * x1d);
                    //x2 = Convert.ToString((-1) * x2d);
                    SendKoords(x1, y1, z1, x2, y2, z2, phi2, Convert.ToByte(port2));  //send koordinaten an nxt2
                    System.Threading.Thread.Sleep(200);                                 //warte kurz
                    SendKoords(x1, y1, z1, x2, y2, z2, phi2, Convert.ToByte(port1));    //send koords an nxt1
                    ReceiveResponse(Convert.ToByte(port2));                                 //antwort abwarten nxt1
                    System.Threading.Thread.Sleep(200);
                    ReceiveResponse(Convert.ToByte(port1));                                 //antwort abwarten nxt2

                    IsBusy = false;                                             //is nich mehr busy
                    if (positionReached != null)                                //event position erreicht triggern

                        positionReached(null, null);

                    DateTime dt = DateTime.Now;                         //datum und uhrzeit
                    string datetime = Convert.ToString(dt);
                    string time = datetime.Substring(11, 8);            //Uhrzeit und koords in protocol schreiben


                    if (checkBox5.Checked == false)
                    {
                        oSheet.Cells[i + 11, 1] = x1;
                        oSheet.Cells[i + 11, 2] = y1;
                        oSheet.Cells[i + 11, 3] = Convert.ToString(Math.Round(z1d - (cb1d / 2)));
                        oSheet.Cells[i + 11, 4] = x2;
                        oSheet.Cells[i + 11, 5] = y2;
                        oSheet.Cells[i + 11, 6] = Convert.ToString(Math.Round(z2d - (cb2d / 2)));
                        oSheet.Cells[i + 11, 8] = ENr;
                        oSheet.Cells[i + 11, 9] = Rad;
                        oSheet.Cells[i + 11, 10] = Vert1;
                        oSheet.Cells[i + 11, 11] = rt;
                        oSheet.Cells[i + 11, 12] = Dist;
                        oSheet.Cells[i + 11, 13] = Vert2;
                        oSheet.Cells[i + 11, 15] = time;
                        oSheet.get_Range("G1", "G1").Interior.ColorIndex = 4;
                    }
                    else if (checkBox5.Checked == false)
                    {
                        StreamWriter myWriter = File.CreateText(@"" + storeloc);
                        myWriter.WriteLine("{0}     {1} / {2} / {3}", time, x1, y1, z1);
                    }

                    int waittime = Convert.ToInt32(textBox15.Text);
                    System.Threading.Thread.Sleep(waittime);

                    dt = DateTime.Now;
                    datetime = Convert.ToString(dt);
                    time = datetime.Substring(11, 8);
                    if (checkBox5.Checked == false)
                    {
                        oSheet.Cells[i + 11, 16] = time;
                        oSheet.get_Range("G1", "G1").Interior.ColorIndex = 3;
                    }
                    else if (checkBox5.Checked == false)
                    {
                        StreamWriter myWriter = File.CreateText(@"" + storeloc);
                        myWriter.WriteLine("{0}     {1} / {2} / {3}", time, x2, y2, z2);
                        myWriter.WriteLine("------------------------- ");
                    }

                }

                if (checkBox1.Checked == true)
                {

                    IsBusy = true;                                      //is busy

                    if (positionLeaved != null)                         //event pos. verlassen triggern

                        positionLeaved(null, null);

                    phi2d = 0;
                    if (checkBox3.Checked == false)
                        phi2d = 2491;

                    string phi2 = Convert.ToString(phi2d);

                    SendKoords("-50", "0", "0", "50", "0", "0", phi2, Convert.ToByte(port2));  //send koordinaten an nxt2
                    System.Threading.Thread.Sleep(200);                                 //warte kurz
                    SendKoords("-50", "0", "0", "50", "0", "0", phi2, Convert.ToByte(port1));    //send koords an nxt1
                    ReceiveResponse(Convert.ToByte(port2));                                 //antwort abwarten nxt1
                    System.Threading.Thread.Sleep(500);
                    ReceiveResponse(Convert.ToByte(port1));                                 //antwort abwarten nxt2

                    IsBusy = false;                                             //is nich mehr busy
                    if (positionReached != null)                                //event position erreicht triggern

                        positionReached(null, null);


                }

                System.Threading.Thread.Sleep(500);
                StopProgram(Convert.ToByte(port1));             //Prgme beenden
                System.Threading.Thread.Sleep(500);
                StopProgram(Convert.ToByte(port2));

                //System.Diagnostics.Process.Start(@"" + storeloc);       //protocol öffnen
            }
            catch (ArgumentException AE)
            {
                MessageBox.Show(Convert.ToString(AE), "Please choose a valid name!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                IsBusy = false;
            }
            catch (FormatException FE)
            {
                MessageBox.Show(Convert.ToString(FE), "Please fill in whole numbers!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                IsBusy = false;
            }
            catch (Exception IOE)
            {
                MessageBox.Show(Convert.ToString(IOE), "Cannot find brick!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                IsBusy = false;

            }
        }


        







    }



}
